from django.http import HttpResponseRedirect, HttpResponse
from django.shortcuts import render, redirect
from django.utils.datastructures import MultiValueDictKeyError
from django.utils.http import urlquote

import csv
import requests
from bs4 import BeautifulSoup
from pyexcel_xls import get_data as xls_get
from pyexcel_xlsx import get_data as xlsx_get

from .forms import DiscogsForm

cookies = {
    'si': 'webami',
    'aec_ai_user': 'aecaiuser_3nyacyjotobn05zlw4qh0yfy',
    '_ga': 'GA1.3.2035065422.1634465281',
    'ai_user': 'xjUln|2021-10-17T10:08:01.545Z',
    'ASP.NET_SessionId': 'l2pdspwt1zadvfavgwv3f0sv',
    'sdc_standard_pool': '259525386.20480.0000',
    '__RequestVerificationToken': 'ig-CWAqr33mwTPtPZhOWU-0hi64Oil4jkJOF_YZ40KhtYlM71ZnSpCOzQQF5dbdxufV4Q3zQx-z-OTSVlK2fRDqk91U1',
    '_gid': 'GA1.3.1086034447.1635589865',
    'WebAMIData': 'pslwCe-0frCgggV%2baO%2f3K.y%3a%5cFIk%60r%5cOv%5c+_p%22U%3e+o01(pOLLMQi1%26UTM*%5dhc%3fm1E%26aO%3fxD%3a%2ba%3fI4FA%5cWbb%5bNx8e%7d%3e%24aSVQFASKP*%3e%3ckqQ)%40eR%5d%2c%2c%5dr%407GI%24%27+a%7ew1x5*FjPpQQpc5%3a%2c-*e%3a%5d%23qqccBCe%7e%3bdC%40U%7e+%26%7cg%601V%2b%5dDGa!s%27WsWvM6c%2c*CVFw9xuowvZW%3e%27WvW-%2feU*6P.h%266U7n%2fWeKl%3dZv%7b%40c%7dfYAp4%5c%2cq%2f%2b%26%5b*Pqy%23GqAR.d%5b_%7bp%7e+L%26ep-t%3dv%3cM4Z%7dl%2cH1w%2bWn%3e%26WMGBvqsnrv%5dW%5d568%25X%22uHVzB%3awV%3a(%3fObM%3e%2cj.+g%40%5dna%2fUnN430(Q%2fV%24-%23W%40n4tQUZunY0gxej%24kM-%5e%3fRhV38Bf%3eH1iXNB6%26XL%27yq!xJTKC8%3e768q%3e%3exH%3cfZtE%60aK5rJ1-%3bn4In%2caN3%3c%26iKi4WWSOK7%2b%3a(%40n4tQU',
    '.ASPXAUTH': '39769891B6B4789182E9C8A118C2A0BC6E892971D22BC041E4CA5BC6C098D4BD0C122F35A1AC6F2C37F22C4D2805649388B50C65A7C26FD25F848CA9D26F9A225044B312B5CACA830135B0D97F35FF3A66AF6FB4',
    'perpage': '25',
    'TS0190620d': '017a3de8bc081b8ba02e4b892f4d1aa3cd10845f92a4ac0661d3d6aadea9b26a9859699881d4a8da6d054e9354c476e628f4454ca7',
    '_gat_newTracker0': '1',
    '_gat_newTracker1': '1',
    'ai_session': 'PPYh6|1635592383072|1635595579312.4',
}

headers = {
    'Connection': 'keep-alive',
    'sec-ch-ua': '"Google Chrome";v="93", " Not;A Brand";v="99", "Chromium";v="93"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Linux"',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.82 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-User': '?1',
    'Sec-Fetch-Dest': 'document',
    'Referer': 'https://webami.aent.com/',
    'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
}


def WebAMIScrapper(request):
    if request.method == 'POST':
        print('request method post if', request)

        image = None
        title = None
        label = None
        upc = None
        genre = None
        release_date = None
        product_id = None
        order_type = None
        weight = None
        description = None
        track_list_data = None
        response = None
        writer = None
        first_row = []

        try:
            excel_file = request.FILES['WebAMI_file']
            data = None
            if str(excel_file).split('.')[-1] == 'xls':
                data = xls_get(excel_file, column_limit=2)
                print('xls data is : ', data)
            elif str(excel_file).split('.')[-1] == 'xlsx':
                data = xlsx_get(excel_file, column_limit=2)
            else:
                return render(request, 'status.html', {'is_download': False})

            for item in data['Sheet1'][4:]:
                print('item is : ', item)
                try:
                    webami_response = requests.get('https://webami.aent.com/{}'.format(item[1]), headers=headers,
                                                   cookies=cookies)
                except Exception as e:
                    print('webami_response exception is : ', e)
                    break
                soup = BeautifulSoup(webami_response.text, 'html.parser')

                try:
                    image = ""
                    image_url = soup.find("div", {"class": "col-xs-12 main-cover"})
                    if image_url is not None:
                        image = image_url.find('img')['src']
                except Exception as e:
                    print('image exception : ', e)
                    image = ""

                try:
                    title = ""
                    title_data = soup.find("li", {"class": "aec-main-title"})
                    if title_data is not None:
                        title = title_data.text.replace('\n', '')
                except Exception as e:
                    print('image exception : ', e)
                    image = ""

                try:
                    label = ""
                    data_len = len(soup.find('div', {'class': 'primaryinfo-holder col-md-8 col-xs-12'}).find_all('li'))
                    if data_len > 0:
                        label = soup.find('div', {'class': 'primaryinfo-holder col-md-8 col-xs-12'}).find_all('li')[
                            0].text.replace('\n', '')
                except Exception as e:
                    print('label exception : ', e)
                    label = ""

                try:
                    upc = ""
                    data_len = len(soup.find('div', {'class': 'primaryinfo-holder col-md-8 col-xs-12'}).find_all('li'))
                    if data_len >= 1:
                        upc = soup.find('div', {'class': 'primaryinfo-holder col-md-8 col-xs-12'}).find_all('li')[
                            1].text.replace('\n', '')
                except Exception as e:
                    print('upc exception : ', e)
                    upc = ""

                try:
                    genre = ""
                    data_len = len(soup.find('div', {'class': 'primaryinfo-holder col-md-8 col-xs-12'}).find_all('li'))
                    if data_len >= 2:
                        genre = soup.find('div', {'class': 'primaryinfo-holder col-md-8 col-xs-12'}).find_all('li')[
                            2].text.replace('\n', '')
                except Exception as e:
                    print('genre exception : ', e)
                    genre = ""

                try:
                    release_date = ""
                    data_len = len(soup.find('div', {'class': 'primaryinfo-holder col-md-8 col-xs-12'}).find_all('li'))
                    if data_len >= 3:
                        release_date = \
                            soup.find('div', {'class': 'primaryinfo-holder col-md-8 col-xs-12'}).find_all('li')[
                                3].text.replace('\n', '')
                except Exception as e:
                    print('release_date exception : ', e)
                    release_date = ""

                try:
                    product_id = ""
                    data_len = len(soup.find('div', {'class': 'primaryinfo-holder col-md-8 col-xs-12'}).find_all('li'))
                    if data_len >= 4:
                        product_id = \
                            soup.find('div', {'class': 'primaryinfo-holder col-md-8 col-xs-12'}).find_all('li')[
                                4].text.replace('\n', '')
                except Exception as e:
                    print('product_id exception : ', e)
                    product_id = ""

                try:
                    order_type = ""
                    data_len = len(soup.find('div', {'class': 'primaryinfo-holder col-md-8 col-xs-12'}).find_all('li'))
                    if data_len >= 5:
                        order_type = \
                            soup.find('div', {'class': 'primaryinfo-holder col-md-8 col-xs-12'}).find_all('li')[
                                5].text.replace('\n', '')
                except Exception as e:
                    print('order_type exception : ', e)
                    order_type = ""

                try:
                    weight = ""
                    data_len = len(soup.find('div', {'class': 'primaryinfo-holder col-md-8 col-xs-12'}).find_all('li'))
                    if data_len >= 6:
                        weight = soup.find('div', {'class': 'primaryinfo-holder col-md-8 col-xs-12'}).find_all('li')[
                            6].text.replace('\n', '')
                except Exception as e:
                    print('weight exception : ', e)
                    weight = ""

                try:
                    description = ''
                    description_data = soup.find("div", {"class": "aec-desc-review collapse"})
                    if description_data is not None:
                        description = description_data.find("p").text.replace('\n', '')
                except Exception as e:
                    print('description exception : ', e)
                    description = ""

                try:
                    track_list_data = ''
                    track_list = soup.find("div", {"class": "jp-playlist"})
                    if track_list is not None:
                        track_list_data = track_list.find_all("li")
                except Exception as e:
                    print('description exception : ', e)
                    track_list = ""

                short_description = str(label) + '\n' + str(upc) + '\n' + str(genre) + '\n' + str(
                    release_date) + '\n' + str(product_id) + '\n' + str(order_type) + '\n' + str(weight) + '\n'

                # long_description = description
                long_description = description + '\n \n' + track_list_data

                song = {
                    'images': image,
                    'title': title,
                    'name': title,
                    'short_description': short_description,
                    'Description': long_description,
                }

                if response is None:
                    response = HttpResponse(
                        content_type='text/csv',
                        headers={'Content-Disposition': 'attachment; filename={}.csv'.format(urlquote(title))},
                    )

                if response is not None:
                    writer = csv.writer(response)
                    first_row_visited = False
                    if len(first_row) < 1:
                        first_row_visited = True
                        first_row = []
                    is_not_fetched = None
                    second_row = []
                    for key, value in song.items():
                        if key == 'images' and value == '':
                            is_not_fetched = False
                        first_row.append(key)
                        second_row.append(value)
                    if is_not_fetched is False:
                        continue
                    else:
                        if first_row_visited is True:
                            writer.writerow(first_row)
                        writer.writerow(second_row)

                # if response is not None:
                #     if writer is None:
                #         writer = csv.writer(response)
                #     first_row = []
                #     second_row = []
                #     is_not_fetched = None
                #     for key, value in song.items():
                #         if key == 'images' and value == '':
                #             is_not_fetched = False
                #         first_row.append(key)
                #         second_row.append(value)
                #         # writer.writerow([key, value])
                #     if is_not_fetched is False:
                #         continue
                #     else:
                #         writer.writerow(first_row)
                #         writer.writerow(second_row)

            return response

        except MultiValueDictKeyError:
            return render(request, 'status.html', {'is_download': False})


    # else:
    #     print('request length is greater then zero else')
    #     return render(request, 'status.html', {'is_download': False})

    else:
        print('request method post else')
        # form = WebAMIForm
        return render(request, 'WebAMI.html', )
        # return render(request, 'index.html', {'form': form, 'is_download': False})


def VintagevinylScrapper(request):
    if request.method == 'POST':
        print('request method post if vintagevinyl', request)

        image = None
        title = None
        label = None
        upc = None
        genre = None
        release_date = None
        product_id = None
        order_type = None
        weight = None
        description = None
        track_list_data = None
        response = None
        first_row = []

        try:
            excel_file = request.FILES['Vintagevinyl_file']
            data = None
            if str(excel_file).split('.')[-1] == 'xls':
                data = xls_get(excel_file, column_limit=2)
                print('xls data is : ', data)
            elif str(excel_file).split('.')[-1] == 'xlsx':
                data = xlsx_get(excel_file, column_limit=2)
            else:
                return render(request, 'status.html', {'is_download': False})

            for item in data['Sheet1'][4:]:
                print('item is : ', item)
                try:
                    vintagevinyl_response = requests.get('https://vintagevinyl.com/UPC/{}'.format(item[1]))
                except Exception as e:
                    print('vintagevinyl_response exception is : ', e)
                    break
                soup = BeautifulSoup(vintagevinyl_response.text, 'html.parser')

                try:
                    image = ""
                    image_url = soup.find("img", {"class": "coverimage img-rounded"})
                    if image_url is not None:
                        image = image_url['src']
                except Exception as e:
                    print('image exception : ', e)
                    image = ""

                try:
                    title = ""
                    title_data = soup.find("div", {"class": "artist-title"})
                    if title_data is not None:
                        title = title_data.text.replace('\n', '')
                except Exception as e:
                    print('title exception : ', e)
                    image = ""

                try:
                    format_type = ""
                    data_len = len(soup.find('table', {'class': 'table'}).find_all('dd'))
                    if data_len > 0:
                        format_type = soup.find('table', {'class': 'table'}).find_all('dd')[0].text.replace('\n', '')
                except Exception as e:
                    print('format_type exception : ', e)
                    format_type = ""

                try:
                    label = ""
                    data_len = len(soup.find('table', {'class': 'table'}).find_all('dd'))
                    if data_len > 1:
                        label = soup.find('table', {'class': 'table'}).find_all('dd')[1].text.replace('\n', '')
                except Exception as e:
                    print('label exception : ', e)
                    label = ""

                try:
                    release_date = ""
                    data_len = len(soup.find('table', {'class': 'table'}).find_all('dd'))
                    if data_len >= 2:
                        release_date = soup.find('table', {'class': 'table'}).find_all('dd')[2].text.replace('\n', '')
                except Exception as e:
                    print('release_date exception : ', e)
                    release_date = ""

                try:
                    upc = ""
                    data_len = len(soup.find('table', {'class': 'table'}).find_all('dd'))
                    if data_len >= 3:
                        # upc = soup.find('table', {'class': 'table'}).find_all('dd')[3].text.replace('\n', '')
                        upc = soup.find('table', {'class': 'table'}).find_all('dd')[data_len-1].text.replace('\n', '')
                except Exception as e:
                    print('upc exception : ', e)
                    upc = ""

                try:
                    artist = ""
                    data_len = len(soup.find('div', {'class': 'item_info'}).find_all('span'))
                    if data_len >= 0:
                        artist = soup.find('div', {'class': 'item_info'}).find_all('span')[0].text.replace('\n', '')
                except Exception as e:
                    print('artist exception : ', e)
                    artist = ""

                try:
                    price = ""
                    data_len = len(soup.find('div', {'class': 'item_info'}).find_all('span'))
                    if data_len >= 1:
                        price = soup.find('div', {'class': 'item_info'}).find_all('span')[1].text.replace('\n', '')
                except Exception as e:
                    print('price exception : ', e)
                    price = ""

                try:
                    track_list = ""
                    data_len = len(soup.find_all('a', {'class': 'track'}))
                    if data_len is not None:
                        for index in range(data_len):
                            track_list += soup.find_all('a', {'class': 'track'})[index].text.replace('\n', '') + '\n'
                except Exception as e:
                    print('track_list exception : ', e)
                    track_list = ""

                try:
                    description = ''
                    description_data = soup.find("div", {"class": "trackplayer_html"}).find_all('span')
                    if description_data is not None:
                        description_index = len(soup.find("div", {"class": "trackplayer_html"}).find_all('span'))
                        description = soup.find("div", {"class": "trackplayer_html"}).find_all('span')[
                            description_index - 1].text.replace('\n', '')
                except Exception as e:
                    print('description exception : ', e)
                    description = ""

                # short_description = 'LABEL:  ' + str(label) + '\n' + 'UPC:  ' + str(upc) + '\n' + 'GENRE:  ' + str(
                #     genre) + '\n' + 'RELEASE DATE:  ' + str(release_date) + '\n' + 'PRODUCT ID:  ' + str(
                #     product_id) + '\n' + 'TYPE:  ' + str(order_type) + '\n' + 'WEIGHT:  ' + str(weight) + '\n'

                sku = upc.replace('UPC: ', '')

                new_title = artist.replace('Artist:', '') + ' - ' + title

                short_description = format_type + '\n' + label + '\n' + release_date + '\n' + upc + '\n' + artist + '\n\n'

                long_description = description + '\n\n' + track_list
                # long_description = track_list_data + '\n \n' + description

                song = {
                    'images': image,
                    'title': title,
                    'sku': sku,
                    # 'title': title,
                    'name': new_title,
                    'short_description': short_description,
                    'Description': long_description,
                    'price': price,
                    'quantity': 30,
                }

                if response is None:
                    response = HttpResponse(
                        content_type='text/csv',
                        headers={'Content-Disposition': 'attachment; filename={}.csv'.format(urlquote(title))},
                    )

                if response is not None:
                    writer = csv.writer(response)
                    first_row_visited = False
                    if len(first_row) < 1:
                        first_row_visited = True
                        first_row = []
                    is_not_fetched = None
                    second_row = []
                    for key, value in song.items():
                        if key == 'images' and value == '':
                            is_not_fetched = False
                        first_row.append(key)
                        second_row.append(value)
                    if is_not_fetched is False:
                        continue
                    else:
                        if first_row_visited is True:
                            writer.writerow(first_row)
                        writer.writerow(second_row)

                # if response is not None:
                #     writer = csv.writer(response)
                #     first_row = []
                #     second_row = []
                #     for key, value in song.items():
                #         first_row.append(key)
                #         second_row.append(value)
                #         # writer.writerow([key, value])
                #     writer.writerow(first_row)
                #     writer.writerow(second_row)

            return response

        except MultiValueDictKeyError:
            return render(request, 'status.html', {'is_download': False})


    # else:
    #     print('request length is greater then zero else')
    #     return render(request, 'status.html', {'is_download': False})

    else:
        print('request method post else')
        # form = VintagevinylForm
        return render(request, 'VintageVinyl.html', )
        # return render(request, 'index.html', {'form': form, 'is_download': False})


def index_listing(request):
    if request.method == 'POST':
        if len(request.POST['discogs_url']) > 0:

            tags = ""
            track_list_data = ""
            # sub_track_data = ""
            track_title_sub_track_data = ""

            k = requests.get(request.POST['discogs_url']).text
            soup = BeautifulSoup(k, 'html.parser')

            try:
                image = ""
                image_url = soup.find("picture")
                if image_url is not None:
                    image = image_url.find("img")['src']
                elif soup.find("span", {"class": "thumbnail_center"}) is not None:
                    image = soup.find("span", {"class": "thumbnail_center"}).find("img")['src']
            except Exception as e:
                print('image exception : ', e)
                image = ""

            try:
                tags = ""
                tags_data = soup.find("span", {"class": "link_15cpV"})
                if tags_data is not None:
                    tags = tags_data.text
            except Exception as e:
                print('tags exception : ', e)
                tags = ""

            try:
                title = ""
                title_data = soup.find("h1", {"class": "header_3FV2N"})
                title_data_2 = soup.find("h1", {"class": "title_1q3xW"})
                if title_data is not None:
                    title = title_data.text
                elif title_data_2 is not None:
                    title = title_data_2.text
                else:
                    title = soup.find("h1", {"class": "hide_mobile has_action_menu"}).text.replace(' ', '').replace(
                        '\n', ' ')
            except Exception as e:
                print('title exception : ', e)
                title = ""

            try:
                label = ""
                label_data_len = len(soup.find_all("div", {"class": "content_3IW3p"}))
                if label_data_len > 0:
                    label_data = soup.find_all("div", {"class": "content_3IW3p"})[0]
                    if label_data is not None:
                        label = label_data.text
                else:
                    label_data = soup.find_all("table", {"class": "table_1fWaB"})[0].find_all("td")[0]
                    if label_data is not None:
                        label = label_data.text
            except Exception as e:
                print('label exception : ', e)
                label = ""

            try:
                format_type = ""
                format_type_data_len = len(soup.find_all("div", {"class": "content_3IW3p"}))
                if format_type_data_len > 1:
                    format_type_data = soup.find_all("div", {"class": "content_3IW3p"})[1]
                    if format_type_data is not None:
                        format_type = format_type_data.text
                else:
                    format_type_data = soup.find_all("table", {"class": "table_1fWaB"})[0].find_all("td")[1]
                    if format_type_data is not None:
                        format_type = format_type_data.text
            except Exception as e:
                print('format_type exception : ', e)
                format_type = ""

            try:
                country = ""
                country_data_len = len(soup.find_all("div", {"class": "content_3IW3p"}))
                if country_data_len > 2:
                    country_data = soup.find_all("div", {"class": "content_3IW3p"})[2]
                    if country_data is not None:
                        country = country_data.text
                else:
                    country_data = soup.find_all("table", {"class": "table_1fWaB"})[0].find_all("td")[2]
                    if country_data is not None:
                        country = country_data.text
            except Exception as e:
                print('country exception : ', e)
                country = ""

            try:
                released = ""
                released_data_len = len(soup.find_all("div", {"class": "content_3IW3p"}))
                if released_data_len > 3:
                    released_data = soup.find_all("div", {"class": "content_3IW3p"})[3]
                    if released_data is not None:
                        released = released_data.text
                else:
                    released_data = soup.find_all("table", {"class": "table_1fWaB"})[0].find_all("td")[3]
                    if released_data is not None:
                        released = released_data.text
                    else:
                        released = soup.find_all("div", {"class": "content"})[2].text.replace('\n', '')
            except Exception as e:
                print('released exception : ', e)
                released = ""

            try:
                genre = ""
                genre_data_len = len(soup.find_all("div", {"class": "content_3IW3p"}))
                if genre_data_len > 4:
                    genre_data = soup.find_all("div", {"class": "content_3IW3p"})[4]
                    if genre_data is not None:
                        genre = genre_data.text
                else:
                    genre_data = soup.find_all("table", {"class": "table_1fWaB"})[0].find_all("td")[4]
                    if genre_data is not None:
                        genre = genre_data.text
                    else:
                        genre = soup.find_all("div", {"class": "content"})[0].text.replace('\n', '')
            except Exception as e:
                print('genre exception : ', e)
                genre = ""

            try:
                style = ""
                style_data_length = len(soup.find_all("div", {"class": "content_3IW3p"}))
                if style_data_length == 6:
                    style = soup.find_all("div", {"class": "content_3IW3p"})[5].text
                elif style_data_length == 5:
                    style_data = soup.find_all("div", {"class": "content_3IW3p"})[4]
                    if style_data is not None:
                        style = soup.find_all("div", {"class": "content_3IW3p"})[4].text
                else:
                    style_data = soup.find_all("table", {"class": "table_1fWaB"})[0].find_all("td")[5]
                    if style_data is not None:
                        style = style_data.text
                    else:
                        style = soup.find_all("div", {"class": "content"})[1].text.replace('\n', '')

            except Exception as e:
                print('style exception : ', e)
                style = ""

            try:
                if len(soup.find_all('table')) > 2:

                    track_alter_list = soup.find_all('table')[2].find_all("span", {"class": "tracklist_track_title"})
                    if len(track_alter_list) < 1:
                        track_alter_list = soup.find_all('table')[1].find_all("tr")

                        for alter_track in track_alter_list:
                            alter_track_position = alter_track.find("td", {"class": "trackPos_2RCje"})
                            alter_track_data = alter_track.find("td", {"class": "trackTitle_CTKp4"})
                            alter_track_position_data = alter_track_position.text + "\n" + alter_track_data.text
                            alter_track_title = alter_track_position_data + "\n \n"
                            # alter_track_title = alter_track.text + "\n \n"
                            track_list_data += alter_track_title

                    # track_alter_list = ""
                    # if len(soup.find_all('table')) > 2:
                    #     track_alter_list = soup.find_all('table')[2].find_all("span", {"class": "tracklist_track_title"})
                    # else:
                    #     track_list_data = ""

                    else:
                        for alter_track in track_alter_list:
                            alter_track_title = alter_track.text + "\n \n"
                            track_list_data += alter_track_title
                else:
                    track_list = soup.find_all("tr")
                    for track in track_list:
                        track_position = ''
                        track_position_data = track.find("td", {"class": "trackPos_2RCje"})
                        if track_position_data is not None:
                            track_position = track.find("td", {"class": "trackPos_2RCje"}).text.replace('/n', "")
                        else:
                            track_position = track.find("td", {"class": "subtrackPos_Vcoq2"}).text.replace('Level Up',
                                                                                                           '')
                        track_artist = track.find("td", {"class": "artist_3zAQD"}).text.replace('/n', "")
                        # track_title_sub_track_data = track.find("td", {"class": "trackTitle_CTKp4"}).text.replace('/n', "")
                        track_title = track.find("td", {"class": "trackTitle_CTKp4"}).text.replace('/n', "")
                        track_div_data = track.find("div", {"class": "credits_12-wp expanded_3odiy"})
                        if track_div_data is not None:
                            track_title = track.find("span", {"class": "trackTitle_CTKp4"}).text
                            sub_track_data = ""
                            for sub_track in track_div_data:
                                sub_track_data += "\t   " + sub_track.text + "\n"
                            track_title = track_title + "\n" + sub_track_data

                            # track_title_sub_track_data = track_title + "\n" + sub_track_data

                            track_data = track_position + " " + track_artist + "\n" + track_title + "\n \n"
                        else:
                            track_data = track_position + " " + track_artist + "\n" + track_title + "\n \n"

                        # track_data = track_position + " " + track_artist + "\n" + track_title_sub_track_data + "\n \n"

                        track_list_data += track_data

                        # track_list_data.append(track_data)
                        # print(track)
            except Exception as e:
                print('track_list exception : ', e)
                # track_list_data = ""

            try:
                description = ''
                description_data = soup.find("div", {"class": "main_2FbVC"})
                if description_data is not None:
                    description = soup.find_all("div", {"class": "main_2FbVC"})[5].find("div").text
            except Exception as e:
                print('description exception : ', e)
                description = ""

            try:
                price = ''
                price_data = soup.find("span", {"class": "price_2Wkos"})
                if price_data is not None:
                    price = price_data.text.replace('/n', "")
            except Exception as e:
                print('price exception : ', e)
                price = ""

            short_description = "Label:  " + label + "\n" + "Format:  " + format_type + "\n" + "Country:  " + country + "\n" + "Released:  " + released + "\n" + "Genre:  " + genre + "\n" + "Style:  " + style

            long_description = track_list_data + " \n \n " + description

            # name = title.replace(' ', '-')

            short_and_long_description = short_description + "\n \n \n" + long_description

            song = {
                "images": image,
                "tags": tags,
                "title": title,
                "name": title,
                "short description": short_description,
                # "categories": genre,
                "Description": long_description,
                # "Description": short_and_long_description,
                "price": price,

                # "Label": label,
                # "Format": format,
                # "Country": country,
                # "Released": released,
                # "Style": style,
                # "Track List": track_list_data,
                # "Description": description,
            }

            file_name = ''.join(e for e in title if e.isalnum())
            # song_file = open(f'{file_name}.csv', "w")

            response = HttpResponse(
                content_type='text/csv',
                headers={'Content-Disposition': 'attachment; filename={}.csv'.format(urlquote(file_name))},
            )

            writer = csv.writer(response)
            first_row = []
            second_row = []
            for key, value in song.items():
                first_row.append(key)
                second_row.append(value)
                # writer.writerow([key, value])
            writer.writerow(first_row)
            writer.writerow(second_row)

            # song_file.close()

            # return render(request, 'status.html', {'is_download': True})
            return response
        else:
            return render(request, 'status.html', {'is_download': False})

        # if a GET (or any other method) we'll create a blank form
    else:

        form = DiscogsForm
        return render(request, 'index.html', {'form': form, 'is_download': False})
