from django.urls import path
from .views import *

urlpatterns = [
    path('', index_listing, name='index'),
    path('webami', WebAMIScrapper, name='webami'),
    path('vintagevinyl', VintagevinylScrapper, name='vintagevinyl')
]