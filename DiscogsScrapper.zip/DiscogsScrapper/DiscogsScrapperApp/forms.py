from django import forms


class WebAMIForm(forms.Form):
    # WebAMI_url = forms.URLField(label='WebAMI URL', max_length=1000)
    WebAMI_file = forms.FileField()


class VintagevinylForm(forms.Form):
    Vintagevinyl_file = forms.FileField()


class DiscogsForm(forms.Form):
    discogs_url = forms.URLField(label='Discogs URL', max_length=1000)
